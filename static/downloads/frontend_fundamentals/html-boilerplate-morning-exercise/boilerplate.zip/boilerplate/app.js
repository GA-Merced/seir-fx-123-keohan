console.log('My app.js file is attached');
