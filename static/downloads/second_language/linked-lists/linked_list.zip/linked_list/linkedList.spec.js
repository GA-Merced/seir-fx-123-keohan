const Node = require('./index').Node
const LinkedList = require('./index').LinkedList

test ( 'Node is a Class or Constructor Function', () => {
   expect( typeof Node ).toEqual('function')
  }
)

test ( 'LinkedList is a Class or Constructor Function', () => {
   expect( typeof LinkedList ).toEqual('function')
  }
)

describe( 'A Node', () =>{
    test('has a data and a next property', ()=>{
       const node = new Node('a', {});
       expect(node.data).toEqual('a');
       expect(typeof node.next === "object" && Object.keys(node.next).length === 0).toBeTruthy()
    })
  }
)

describe('InsertFirst', ()=>{
  test('add a new node to the start of the List', ()=>{
    const l = new LinkedList();
      l.insertFirst('maha')
      expect(l.head.data).toEqual('maha')
     l.insertFirst('is awesome')
     expect(l.head.data).toEqual('is awesome')
     expect(l.head.next.data).toEqual('maha')
  })
})

describe('Size', ()=>{
  test('returns number of nodes in Linked List', ()=>{
    const list = new LinkedList();
    list.insertFirst('a');
    list.insertFirst('b');
    list.insertFirst('c');
    expect(list.size()).toEqual(3)
  })
  test('returns large numebr of nodes', ()=>{
    const list = new LinkedList();
    const count = 2364
    for(let i =0; i < count; i++){
      list.insertFirst(i)
    }
    expect(list.size()).toEqual(count)
  })
})
