function Footer(props) {
    return (
      <footer>
        <h1>Footer</h1>
      </footer>
    );
}

export default Footer;
