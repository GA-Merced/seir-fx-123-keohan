function Nav(props) {
    return (
      <nav>
        <h1>Nav</h1>
      </nav>
    );
}

export default Nav;
