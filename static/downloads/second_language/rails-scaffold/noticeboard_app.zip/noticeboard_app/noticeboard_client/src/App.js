function App() {
  return (
    <div className="App">
      <h1>Notices</h1>
    </div>
  )
}

export default App
