const router = require('express').Router();

router.get('/', function(req, res) {
  res.redirect('/students');
});

module.exports = router;