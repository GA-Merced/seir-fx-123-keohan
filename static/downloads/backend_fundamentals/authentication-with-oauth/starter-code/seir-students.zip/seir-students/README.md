# SEIR Students!

**Welcome, Intrepid Learners**

We'll use this project to practice and learn how to work with authentication/authorization using Oauth!